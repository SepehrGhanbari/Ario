# Version History

0.1 — 12 October 2026. First documented Persian edition with 30 chapters, three appendices, and 33 external references.

0.2 — 13 October 2026. Complete English translation; matching Persian release; original bilingual author note on psychological well-being restored at the front of both books; separate reader notice; added A09 and R34; public bilingual Zenodo preparation package. No new Ario code changes or test executions. No publication or DOI registration performed.

# تاریخ نسخه‌ها

۰٫۱ — ۱۲ اکتبرِ ۲۰۲۶. نخستین نسخهٔ مستند فارسی، با ۳۰ فصل، سه پیوست و ۳۳ منبع بیرونی.

۰٫۲ — ۱۳ اکتبرِ ۲۰۲۶. ترجمهٔ کامل انگلیسی و نسخهٔ فارسیِ هم‌تراز؛ افزودن متنِ اصلیِ یادداشتِ دوزبانهٔ سلامت روان در ابتدای کتاب‌ها، راهنمای جداگانهٔ خواننده، منابع A09 و R34 و بستهٔ عمومیِ آمادهٔ زنودو. کد آریو تغییر نکرد و آزمون تازه‌ای اجرا نشد. انتشار و ثبت DOI انجام نشده است.
