ARIO CLEAN PINNED ZIP
Repository: https://github.com/SepehrGhanbari/Ario
Source commit: 3d7708b1be12209a69515fef7434ff2b5cce6580
Audited 234 original Git paths; stored 213 original text/code blobs and 13 original binary blobs.
Excluded 7 nested repository exports; indexed 1 byte-identical duplicates.
Full manifest with all source SHA-256 and original Git blob IDs: EXPORT_META/manifest.json.
Matching TXT is a text-only rendering of the same pinned original Git commit.
This is a deduplicated/nonrecursive release, not an exact Git history or a bit-for-bit copy of all tracked source paths.
