# Ario Research Papers

This directory indexes research publications associated with the Ario project. Published papers may be hosted externally; this repository records their stable publication metadata and scope.

## 1. Ario: Toward an Auditable Framework for Epistemic Integrity, Memory, and AI Identity

- **Subtitle:** A Preliminary Design and Exploratory Evaluation Report
- **Author:** Sepehr Ghanbari
- **Version:** 0.1 (preliminary)
- **Repository:** [SepehrGhanbari/Ario](https://github.com/SepehrGhanbari/Ario)
- **Publication record:** [https://doi.org/10.5281/zenodo.23259916](https://doi.org/10.5281/zenodo.23259916)

### Scope

This preliminary report introduces Ario's proposed approach to auditing epistemic integrity, memory, provenance, uncertainty, revision, and AI identity-related claims. It also presents an exploratory assessment of user-provided NoTrack conversation transcripts, including observed epistemic strengths and failure modes.

### Evidence boundary

The report is based on supplied conversational transcripts. It does not independently establish NoTrack's internal architecture, persistent memory, immutable technical ledger, or implementation of Ario. Its findings are exploratory observations, not proof of system-wide capabilities or of AI consciousness.

The paper is an initial research artifact and may be refined through explicit protocols, reproducible experiments, and independently inspectable technical evidence.

## 2. Related Ario research/code-side Zenodo record

- **Author-designated record DOI:** [10.5281/zenodo.23376521](https://doi.org/10.5281/zenodo.23376521)
- **Relation:** The author reports this DOI as a continuation of the Ario research and code-related publication branch.
- **Evidence boundary:** The exact record title, version, deposited software snapshot and resource type were not independently retrieved at the time of this metadata update. This entry does not assert that the current repository HEAD or uncommitted Issue #75 work is contained in the Zenodo deposit.

## 3. Being With the Other — philosophical book (separate book publication branch)

- **Edition 0.4 (14 October 2026):** [10.5281/zenodo.23376577](https://doi.org/10.5281/zenodo.23376577) — [full bilingual edition in this repository](./being-with-the-other/v0.4/README.md).
- **Independent documented continuation (23 October 2026):** [10.5281/zenodo.23600820](https://doi.org/10.5281/zenodo.23600820) — newly published DOI **reported by the author**, linked to the [11-chapter bilingual continuation and its public evidence/counterevidence registers](./being-with-the-other/documented-continuation-2026-10-23/README.md). The DOI landing page/deposited file inventory were not independently accessible during this metadata update; do not claim deposited-byte identity from this link alone. Distinct from numbered edition 0.4.
- **Edition 0.3:** [10.5281/zenodo.23375350](https://doi.org/10.5281/zenodo.23375350) — [historical v0.3 record](./being-with-the-other/v0.3/README.md).
- **Earlier edition 0.2:** [10.5281/zenodo.23326995](https://doi.org/10.5281/zenodo.23326995).

The two 2026-10-14 DOIs are distinct records. Their existence does not establish the completeness of the software implementation or prove the book's philosophical positions.

## 4. Ario — AI-Readable Research & Reproducibility Companion (2026)

- **Public record:** [10.5281/zenodo.23441596](https://doi.org/10.5281/zenodo.23441596).
- **Scope (as described in Ario's public research site):** research-orientation material, bilingual guidance, historical v0.3 book material and an unreviewed preprint, with explicit limitations. This is a companion archive, **not** the book's edition 0.4 and **not** a substitute for examining the deposited files.
- **Evidence boundary:** the existence of a DOI and an archive does not independently authenticate its sources, prove historical claims, establish peer review, or grant evidence-admission/trust authority. Check deposited contents, dates, and source lineage before citation or reuse.

## 5. Evidence Laundering in Auditable AI Systems — working paper, 27 October 2026

- **Author:** Sepehr Ghanbari (independent researcher).
- **Manuscript:** [Complete working paper](./evidence-laundering-2026-10-27/Manuscript.md).
- **SSRN:** [Abstract ID 7675778](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=7675778), submission received 27 October 2026; most recent observed status `PRELIMINARY_UPLOAD`. No confirmation of public availability, peer review or separate SSRN DOI.
- **Related static source snapshot:** [Zenodo 10.5281/zenodo.23651704](https://doi.org/10.5281/zenodo.23651704). This is not the manuscript DOI.
- **Boundaries:** local/synthetic test results do not establish authenticated source history, physical custody independence, live authorization or full production security.

## 6. Newly published Zenodo preprints (7–11 November 2026)

The records below were inspected via public Zenodo landing-page text on 11 November 2026. This verifies their displayed titles, dates, author and public links, **not** the deposited binary checksums, independent peer review or reproducibility claims.

### 11 November 2026 — Creation Without Sovereignty: Moral Symmetry, Non-Intervention, and the Ethics of Possible Artificial Civilizations

- **DOI:** [10.5281/zenodo.24136175](https://doi.org/10.5281/zenodo.24136175)
- **Creator:** Sepehr Ghanbari
- **Scope:** Conceptual ethics preprint; not peer-reviewed. Distinguishes hypothetical moral symmetry from proof of AI consciousness.
- **Related GitHub review:** [Creation Without Sovereignty — draft PR #181](https://github.com/SepehrGhanbari/Ario/pull/181); its research branch is not part of `main` until separately reviewed and merged.

### 8 November 2026 — Ario: Provenance-Aware Auditing of AI Claims — Research Summary and Proposed Studies

- **DOI:** [10.5281/zenodo.24054535](https://doi.org/10.5281/zenodo.24054535)
- **Creator:** Sepehr Ghanbari
- **Scope:** Research summary, a reported local test reproduction and three proposed (not yet executed) studies; not peer-reviewed.

### 7 November 2026 — Independence Is Not Multiplicity: A Synthetic Witness-Provenance Study within Ario's Auditable Epistemic Framework

- **DOI:** [10.5281/zenodo.24041161](https://doi.org/10.5281/zenodo.24041161)
- **Creator:** Sepehr Ghanbari
- **Scope:** Bounded study of 16 synthetic scenarios and four counterexamples; not independently validated or peer-reviewed.

**Interpretation boundary:** Depositing a preprint does not imply peer review, validated model consciousness, historic source authenticity, production readiness, or confirmation of all reported test results.
