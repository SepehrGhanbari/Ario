ARIO / CLEAN SOURCE ZIP — PINNED SOURCE SNAPSHOT
Repository: https://github.com/SepehrGhanbari/Ario
Source commit: a0431e5e294a5c1169d17d18e28312b7fe234855
Snapshot date: 2026-11-12
Git-tracked input blobs verified against Git SHA-1: 215
Source files carried with their original bytes: 208
  - Distinct text/code originals: 197
  - Distinct genuine binary project assets: 11 (PDF, DOCX, published ZIP)
Omitted redundant repository exports: 6
Omitted one identical text copy: 1 (path and matching SHA in manifest)
No archive-within-archive of earlier entire Ario repository snapshots.
All meaningful code, text, documents, PDFs and original assets for the pinned
source commit are included with their exact repo-relative original paths.
See EXPORT_META/manifest.json for the full 215-file audited inventory;
text-file source and aliases use the same inventory as the paired
ario-source-clean.txt (sha256 0b78796c9e2afe361951c590297538cfe881409046cc9e6f64371cb76800b77c).
This is a deliberately deduplicated archive, NOT an exact 215-entry Git
tree restoration. For 215 entries including historical exported copies,
retrieve the pinned source commit or its full GitHub archive directly.
Git commit history and untracked/off-repository files are out of scope.
