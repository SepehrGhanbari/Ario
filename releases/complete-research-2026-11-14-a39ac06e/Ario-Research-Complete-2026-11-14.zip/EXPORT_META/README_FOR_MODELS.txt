ARIO VERIFIED RESEARCH CORPUS - 14 November 2026
Source main commit: a39ac06e69c1b5115bca2016698556730bf920cd
All original Git blobs are SHA-1 and size audited. Unique research, experiments, code and source files are included.
The matching TXT orders research first. Both book PDFs from Zenodo 23771218 are original, with extracted text.
LIMITATION: Zenodo labels book record Version 6, source PDFs say Fifth Integrated Edition. This unresolved source distinction is not corrected by invention.
Earlier book v0.2-v0.4 complete manuscripts and older full-repo snapshots are not embedded again; their path, hashes and preservation location remain in SOURCE_MANIFEST.
Original PDF images/layout remain in PDF; TXT extraction does not promise all image content. Private/unmerged PR work is not in public main source.
EXP/TEST COVERAGE: see EXPORT_META/RESEARCH_AND_EXPERIMENT_COVERAGE.json.
